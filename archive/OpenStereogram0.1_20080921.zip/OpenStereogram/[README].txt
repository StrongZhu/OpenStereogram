To run Open Stereogram:

- On Windows: execute run.bat

- On Linux: execute run.sh (don't forget to give execution privileges)

Make sure your machine has Java Runtime Environment (JRE) installed.
You can download Java Runtime Environment for free on http://www.java.com.

For more info please visit Open Stereogram site:
http://gfcaprojects.googlepages.com/openstereogram